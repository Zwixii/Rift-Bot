# PeelyBot

## Github : [click here](https://github.com/noteason)
## TikTok : [@PeelyBotFn](https://tiktok.com/@peelybotfn)
## DISCORD SERVER : [PeelyBot](https://discord.gg/5GSdFtcApG)
##
# HOW TO USE PEELYBOT
## 1) Go to [EpicGames](https://epicgames.com/id/register) and sign up for the bots account

## 2) Go to [config.json]() and put in the email and password you used to sign up.

## 3) (optional) Change the status and cosmetic items that the bot joins with [click here to find item id's](https://fortnite-archive.fandom.com/wiki/Fortnite_Wiki)

## 4) If you would like admin to your bot please go to [config.json]()
## 5) Run the project using the run button at the very top
## 6) Wait for the packages install (usually takes 2-5 minutes)
## 7) The project will ask for an valid auth code [click here to get the code](https://www.epicgames.com/id/logout?redirectUrl=https%3A//www.epicgames.com/id/login%3FredirectUrl%3Dhttps%253A%252F%252Fwww.epicgames.com%252Fid%252Fapi%252Fredirect%253FclientId%253D3446cd72694c4a4485d81b77adbb2141%2526responseType%253Dcode)

## 8) Once you login it will take you to a white page and will have this text  
{"redirectUrl":"com.epicgames.fortnite://fnauth/?code=2cba0035c2fc41a1835d28dd95ca4244","sid":null}
## ONLY COPY THE CONTENT AFTER CODE= AND BEFORE THE QUOTES. EXAMPLE 2cba0035c2fc41a1835d28dd95ca4244

# NOW JUST ADD YOUR BOT ON FORTNITE AND YOUR DONE! 
### Credits : terbau(fortnitepy). Oli (some of the code)